package pl.edu.pw.mini.gapso.utils;

import com.google.gson.Gson;

public class Util {
    public static final Gson GSON = new Gson();
}
