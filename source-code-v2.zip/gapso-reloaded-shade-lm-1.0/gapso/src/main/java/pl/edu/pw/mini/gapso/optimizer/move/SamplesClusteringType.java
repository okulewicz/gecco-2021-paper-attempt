package pl.edu.pw.mini.gapso.optimizer.move;

public enum SamplesClusteringType {
    LARGEST,
    BEST,
    NONE
}
